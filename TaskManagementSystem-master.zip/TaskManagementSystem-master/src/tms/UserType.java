package tms;

public enum UserType{
    Employee,
    Admin,
    Leader
}